/* KONFIGURASI LEXIO STORE
   Isi dengan data dari Firebase: Project settings > Your apps > Web app > Config.
   File ini boleh kamu edit langsung di GitHub (ikon pensil). */
window.LEXIO_CONFIG = {
  firebase: {
    apiKey: "ISI_API_KEY",
    authDomain: "ISI_PROJECT_ID.firebaseapp.com",
    projectId: "ISI_PROJECT_ID",
    storageBucket: "ISI_PROJECT_ID.appspot.com",
    messagingSenderId: "ISI_SENDER_ID",
    appId: "ISI_APP_ID"
  },
  /* Web client ID untuk login Google di aplikasi Android.
     Ambil dari Firebase Console > Authentication > Sign-in method > Google > Web SDK configuration > Web client ID.
     Bentuknya: 1234567890-abcdef.apps.googleusercontent.com */
  googleWebClientId: "ISI_WEB_CLIENT_ID",
  /* Cek update otomatis dari GitHub Releases. Isi dengan "usernamekamu/nama-repo".
     Hanya berfungsi kalau repo PUBLIK. Kosongkan kalau repo privat. */
  updateRepo: ""
};
