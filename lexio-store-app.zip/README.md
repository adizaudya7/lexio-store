# Lexio Store: paket aplikasi Android

Aplikasi ini dibangun otomatis oleh GitHub menjadi file APK, lalu kamu unduh dan pasang di HP Android.

## Isi repo yang perlu ada (cara paling mudah, cukup 4 hal)
1. `.github/workflows/lexio.yml` (dibuat manual, lihat langkah 3)
2. `lexio-store-app.zip` (upload file ZIP ini apa adanya, jangan diekstrak)
3. `lexio-config.js` (konfigurasi Firebase, bisa diedit langsung di GitHub)
4. `google-services.json` (dari Firebase, lihat langkah 6)

## Langkah-langkah
**1. Buat repo.** GitHub > New repository > nama `lexio-store` > pilih **Private** > Create.

**2. Upload ZIP dan config.** Di repo: Add file > Upload files > pilih `lexio-store-app.zip` dan `lexio-config.js` > Commit changes.

**3. Buat workflow.** Add file > Create new file. Pada kolom nama ketik persis: `.github/workflows/lexio.yml`
(setelah mengetik `/`, folder akan terbentuk otomatis). Buka file `lexio.yml`, salin seluruh isinya, tempel, lalu Commit.

**4. Buat kunci tanda tangan (sekali seumur hidup app).**
Tab Actions > "Lexio Store APK" > Run workflow > aksi `buat-keystore` > Run.
Setelah hijau, buka run itu, lihat bagian **Summary**. Di sana ada 4 nilai untuk Secrets dan 1 nilai SHA-1.
Settings > Secrets and variables > Actions > New repository secret, buat 4 secret:
`KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` (isi sesuai Summary).
Lalu **hapus run itu** (titik tiga > Delete workflow run). SIMPAN nilai-nilainya juga di tempat aman: kunci ini
tidak boleh berganti, kalau berganti, aplikasi lama tidak bisa di-update.

**5. Siapkan Firebase** (console.firebase.google.com):
- Buat proyek. Build > Authentication > Sign-in method > aktifkan **Google**.
- Build > Firestore Database > Create database. Tab Rules, tempel lalu Publish:
  `rules_version = '2'; service cloud.firestore { match /databases/{db}/documents { match /users/{uid} { allow read, write: if request.auth != null && request.auth.uid == uid; } } }`
- Project settings > Your apps > tambah **Web app** (ikon `</>`), salin konfigurasinya, lalu edit `lexio-config.js` di GitHub dan ganti semua `ISI_...`.

**6. Daftarkan aplikasi Android di Firebase.**
Project settings > Add app > Android. Package name: `id.lexiostore.app`. Setelah dibuat, buka pengaturan app tersebut >
**Add fingerprint** > tempel SHA-1 dari langkah 4. Lalu (opsional untuk versi ini) unduh `google-services.json` (unduh SETELAH menambahkan SHA-1
dan mengaktifkan Google di langkah 5), dan upload ke repo (nama persis `google-services.json`, di folder utama).

**7. Bangun APK.** Repo > Releases > Create a new release > tag `v1.0.0` (Create new tag) > Publish release.
Tunggu sekitar 8 sampai 12 menit di tab Actions sampai hijau. File `Lexio-Store-v1.0.0.apk` muncul di halaman Release.

**8. Pasang di HP.** Buka halaman Release di HP (login GitHub), unduh APK, buka filenya, izinkan "Install dari sumber tidak dikenal", lalu Install.

## Memperbarui aplikasi
Upload `lexio-store-app.zip` yang baru (timpa yang lama) > buat Release baru dengan nomor lebih tinggi (v1.0.1, v1.1.0, dan seterusnya).
APK baru bisa dipasang menimpa yang lama, data tidak hilang karena kunci tanda tangannya sama.

## Cek update otomatis di dalam aplikasi (opsional)
Isi `updateRepo` di `lexio-config.js` dengan `usernamekamu/lexio-store`. Fitur ini hanya bekerja jika repo **publik**.
Kalau repo privat, biarkan kosong dan unduh APK baru lewat halaman Releases.

## Kalau ada error
- Merah di "Tanda tangan APK": secret belum diisi (langkah 4).
- Peringatan `googleWebClientId belum diisi`: tambahkan baris `googleWebClientId` di `lexio-config.js` (Firebase > Authentication > Sign-in method > Google > Web SDK configuration > Web client ID).
- "SHA-1 belum terdaftar" saat login: SHA-1 belum ditambahkan, atau `google-services.json` diunduh sebelum SHA-1 ditambahkan.
- Salin pesan error dari tab Actions dan kirim ke Kara.
